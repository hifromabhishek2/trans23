import { Component, OnInit } from '@angular/core';
import { LoginSecurityService } from '../service/login-security.service';
import { appUsersAuth } from '../security/app-users-auth';

@Component({
  selector: 'app-dialog',
  templateUrl: './dialog.component.html',
  styleUrls: ['./dialog.component.css']
})
export class DialogComponent implements OnInit {
  securityObject: appUsersAuth = null;
  constructor(private securityService: LoginSecurityService) {
    

    this.securityObject = this.securityService.securityObject;
   }

  ngOnInit() {
  }
  closeNav() {
   
      document.getElementById("mySidenav").style.width = "0";
      document.getElementById("main").style.marginLeft= "0";
      document.body.style.backgroundColor = "white";
    }


}
